
import pandas as pd
import matplotlib.pyplot as plt

# Load datasets
games = pd.read_csv('games.csv')
sales = pd.read_csv('vgsales.csv')

# Data cleaning
games.drop_duplicates(inplace=True)
sales.drop_duplicates(inplace=True)

games['Rating'].fillna(games['Rating'].mean(), inplace=True)
games['Plays'].fillna(0, inplace=True)
games['Wishlist'].fillna(0, inplace=True)

# Merge datasets
merged = pd.merge(
    games,
    sales,
    left_on=['Title', 'Platform'],
    right_on=['Name', 'Platform'],
    how='inner'
)

# EDA Example
genre_sales = merged.groupby('Genre')['Global_Sales'].sum().sort_values(ascending=False)
genre_sales.plot(kind='bar', title='Global Sales by Genre')
plt.show()
