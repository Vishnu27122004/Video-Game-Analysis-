
# Video Game Sales & Engagement Analysis
# Python: Data Cleaning, Merging, and EDA

import pandas as pd
import matplotlib.pyplot as plt

# Load datasets
games = pd.read_csv("games.csv")
sales = pd.read_csv("vgsales.csv")

# ---------------- Data Cleaning ----------------
games.drop_duplicates(inplace=True)
sales.drop_duplicates(inplace=True)

games['Rating'].fillna(games['Rating'].mean(), inplace=True)
games['Plays'].fillna(0, inplace=True)
games['Wishlist'].fillna(0, inplace=True)

# ---------------- Data Merging ----------------
merged = pd.merge(
    games,
    sales,
    left_on=['Title', 'Platform'],
    right_on=['Name', 'Platform'],
    how='inner'
)

print("Merged Dataset Preview:")
print(merged.head())

# ---------------- EDA ----------------

# 1. Global Sales by Genre
genre_sales = merged.groupby('Genre')['Global_Sales'].sum().sort_values(ascending=False)
genre_sales.plot(kind='bar', title='Global Sales by Genre')
plt.xlabel('Genre')
plt.ylabel('Global Sales')
plt.tight_layout()
plt.show()

# 2. Rating vs Global Sales
plt.scatter(merged['Rating'], merged['Global_Sales'])
plt.xlabel('User Rating')
plt.ylabel('Global Sales')
plt.title('Rating vs Global Sales')
plt.tight_layout()
plt.show()

# 3. Top 10 Best Selling Games
top_games = merged[['Name', 'Global_Sales']].sort_values(by='Global_Sales', ascending=False).head(10)
print("\nTop 10 Best Selling Games:")
print(top_games)

# 4. Wishlist vs Sales
plt.scatter(merged['Wishlist'], merged['Global_Sales'])
plt.xlabel('Wishlist Count')
plt.ylabel('Global Sales')
plt.title('Wishlist vs Global Sales')
plt.tight_layout()
plt.show()
