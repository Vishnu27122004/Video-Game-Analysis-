
-- Video Game Sales & Engagement Analysis
-- SQL Database and Queries

CREATE DATABASE IF NOT EXISTS video_game_db;
USE video_game_db;

-- ---------------- Games Table ----------------
CREATE TABLE games (
    game_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    rating FLOAT,
    genre VARCHAR(100),
    platform VARCHAR(100),
    plays INT,
    wishlist INT
);

-- ---------------- Sales Table ----------------
CREATE TABLE sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    platform VARCHAR(100),
    na_sales FLOAT,
    eu_sales FLOAT,
    jp_sales FLOAT,
    other_sales FLOAT,
    global_sales FLOAT
);

-- ---------------- Queries ----------------

-- Top 10 Best Selling Games
SELECT title, global_sales
FROM sales
ORDER BY global_sales DESC
LIMIT 10;

-- Platform-wise Sales
SELECT platform, SUM(global_sales) AS total_sales
FROM sales
GROUP BY platform
ORDER BY total_sales DESC;

-- Genre-wise Global Sales
SELECT g.genre, SUM(s.global_sales) AS total_sales
FROM games g
JOIN sales s
ON g.title = s.title AND g.platform = s.platform
GROUP BY g.genre
ORDER BY total_sales DESC;

-- Rating vs Sales
SELECT g.rating, s.global_sales
FROM games g
JOIN sales s
ON g.title = s.title;
