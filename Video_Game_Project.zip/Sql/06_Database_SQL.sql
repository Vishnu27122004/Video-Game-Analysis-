
CREATE TABLE games (
    game_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    rating FLOAT,
    genre VARCHAR(100),
    platform VARCHAR(100),
    plays INT,
    wishlist INT
);

CREATE TABLE sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    platform VARCHAR(100),
    na_sales FLOAT,
    eu_sales FLOAT,
    jp_sales FLOAT,
    other_sales FLOAT,
    global_sales FLOAT
);

SELECT genre, SUM(global_sales) AS total_sales
FROM sales
GROUP BY genre
ORDER BY total_sales DESC;
